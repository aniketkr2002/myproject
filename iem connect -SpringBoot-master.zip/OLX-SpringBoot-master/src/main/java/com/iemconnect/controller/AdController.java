package com.iemconnect.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.iemconnect.assemblers.AdModelAssembler;
import com.iemconnect.converter.AdConverter;
import com.iemconnect.dto.*;
import com.iemconnect.execption.LocationNotFoundException;
import com.iemconnect.model.Account;
import com.iemconnect.model.Ad;
import com.iemconnect.model.Advertiser;
import com.iemconnect.repository.AccountRepository;
import com.iemconnect.repository.AdvertiserRepository;
import com.iemconnect.service.AccountService;
import com.iemconnect.service.AdService;
import com.iemconnect.util.AdIdInput;
import com.iemconnect.util.ImgToken;
import com.iemconnect.util.Schedule;
import com.iemconnect.util.Utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@CrossOrigin

public class AdController {
    @Autowired
    private AdService adService;
    @Autowired
    private AdModelAssembler adModelAssembler;
    @Autowired
    private AccountService accountService;
    @Autowired
    private Utils utils;
    @Autowired
    private Schedule schedule;
    @Autowired
    private AdConverter adConverter;
    @Autowired
    private ImgToken imgToken;

       //should be response here
       @GetMapping("/ads/{id}")
        public EntityModel<AdDto> oneAd (@PathVariable("id") Long id) {

        return adModelAssembler.toModel(adService.getAd(id));
        }

        @GetMapping("/home")
        public CollectionModel<EntityModel<MiniAdDto>> all () {

           return adModelAssembler.toCollectionModel(adService.getHomeAds());
        }


        @GetMapping("/test/{id}")
       public List<Long> test (@PathVariable Long id) throws IOException {
          return utils.getLocationAllChildren(new Long(id));
        }

        @GetMapping("/adding")
        public ResponseEntity<UserInfo> addAd (Principal principal){
            UserInfo userInfo = new UserInfo();
            Optional<Principal> p = Optional.ofNullable(principal);
           if(p.isPresent()){
               Account account =accountService.getAccountByEmail(principal.getName())
                       .orElseThrow(() -> new UsernameNotFoundException("No Such Account"));
                   userInfo.setEmail(account.getEmail());
                   userInfo.setPhone(account.getAdvertiser().getPhone());
                   userInfo.setName(account.getAdvertiser().getName());

           }

            return new ResponseEntity<UserInfo>(userInfo,HttpStatus.OK);
        }

        @PostMapping("/adding")
        public ResponseEntity<EntityModel<AdDto>> createAd(@RequestBody @Valid AdInputDto adInputDto){
            System.out.println("start adding");
                Ad ad= adService.saveAd(adConverter.adInputDtoToAd(adInputDto));
                AdDto adDto = adConverter.entityToDto(ad);
               return new ResponseEntity<EntityModel<AdDto>>(adModelAssembler.toModel(adDto),HttpStatus.CREATED) ;
        }

        @GetMapping("/token")
        public ResponseEntity<ImgToken> getImgToken (){
               return new ResponseEntity<ImgToken>(imgToken,HttpStatus.OK);
        }
        //need more work
        @PostMapping("/saveAd")
       public ResponseEntity<?> saveAd (@RequestBody AdIdInput adId, Principal principal ){
            Account account =accountService.getAccountByEmail(principal.getName())
                    .orElseThrow(() -> new UsernameNotFoundException("No Such Account"));
            Long advertiserId = account.getAdvertiser().getId();
             adService.saveAdByUser(advertiserId,adId.getAdId());
             return new ResponseEntity<>(HttpStatus.OK);

        }

        @GetMapping("/canEdit/{adId}/{userId}")
        public Boolean canEdit(@PathVariable Long adId , @PathVariable Long userId){
           return adService.IsAdBelongsToUser(adId, userId);
        }

        @DeleteMapping("/unSave/{adId}")
        public ResponseEntity<?> unSaveAd(@PathVariable Long adId , Principal principal){
            Account account =accountService.getAccountByEmail(principal.getName())
                    .orElseThrow(() -> new UsernameNotFoundException("No Such Account"));
            Long advertiserId = account.getAdvertiser().getId();
            adService.unSaveAd(adId , advertiserId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);

        }
       //return only Ids
        @GetMapping("/mySavedAds")
       public ResponseEntity<List<Long>> getSavedAdsByUser(Principal principal){
            Account account =accountService.getAccountByEmail(principal.getName())
                    .orElseThrow(() -> new UsernameNotFoundException("No Such Account"));
            Long advertiserId = account.getAdvertiser().getId();
           List<Long>  ads = adService.getSavedAdsByUser(advertiserId);
           return new ResponseEntity<>(ads , HttpStatus.OK);
        }

    @GetMapping("myaccount/savedAds")
    public ResponseEntity<List<MiniAdDto>> getSavedAds (Principal principal) throws IOException {
        Account account =accountService.getAccountByEmail(principal.getName())
                .orElseThrow(() -> new UsernameNotFoundException("No Such Account"));
        List<Ad> saved = account.getAdvertiser().getSaved().stream().collect(Collectors.toList());
        List<MiniAdDto> savedList =  adConverter.listEntityToDto((ArrayList<Ad>) saved);
        return new ResponseEntity<>(savedList, HttpStatus.OK);
    }






}
