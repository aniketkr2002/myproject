package com.iemconnect.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.iemconnect.dto.AccountDto;
import com.iemconnect.execption.IncorrectUserOrPassException;
import com.iemconnect.model.Advertiser;
import com.iemconnect.security.AuthenRequest;
import com.iemconnect.security.AuthenResponse;
import com.iemconnect.security.JwtUtil;
import com.iemconnect.service.AdvertiserService;

import javax.validation.Valid;

@RestController
@CrossOrigin

public class AdvertiserController {
    @Autowired
    private AdvertiserService advertiserService;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private  JwtUtil jwtUtil;



    @PostMapping("/register")
    public ResponseEntity<Advertiser> createAccount (@RequestBody @Valid AccountDto accountDto){
       Advertiser advertiser =advertiserService.saveAdvertiser(accountDto);
        return new ResponseEntity<>(advertiser,HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<?> createAuthToken (@RequestBody AuthenRequest authenRequest) throws Exception {
        try {

        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenRequest
        .getUsername(),authenRequest.getPassword()));
        } catch (BadCredentialsException e){
            throw new IncorrectUserOrPassException("incorrect Email or password");
        }

        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenRequest.getUsername());
        final String jwt = jwtUtil.generateToken(userDetails);
        Advertiser advertiser = advertiserService.getAdvertiserByEmail(authenRequest.getUsername());
        return ResponseEntity.ok(new AuthenResponse(jwt ,advertiser.getId(),advertiser.getName(), advertiser.getPhone(),authenRequest.getUsername()));



    }









}
