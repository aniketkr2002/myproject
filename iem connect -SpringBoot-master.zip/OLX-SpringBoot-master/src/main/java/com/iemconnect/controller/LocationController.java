package com.iemconnect.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.PagedModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.iemconnect.dto.MiniAdDto;
import com.iemconnect.model.Location;
import com.iemconnect.service.LocationService;


@RestController
@CrossOrigin

public class LocationController {
    @Autowired
    private LocationService locationService;
    @Autowired
    private PagedResourcesAssembler pagedResourcesAssembler;


    @GetMapping("/location/{locationName}")
    public ResponseEntity<PagedModel<MiniAdDto>> getAdByLocation (@PathVariable String locationName, Pageable pageable){
        //Location location =locationService.getLocationIdByName(locationName);


        //Page<EntityModel<MiniAdDto>> adDtoPage = locationService.getAdByLocation(location.getId(),pageable);
        Page<EntityModel<MiniAdDto>> adDtoPage =locationService.getAdsByLocation(locationName,pageable);
        PagedModel pagedModel = pagedResourcesAssembler.toModel(adDtoPage);
        return new ResponseEntity<>(pagedModel, HttpStatus.OK);
    }
}
