package com.iemconnect.dto;

import lombok.Data;


@Data
public class RelevantAdDto extends MiniAdDto {

}
