package com.iemconnect.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iemconnect.model.Account;
import com.iemconnect.model.Ad;
import com.iemconnect.model.Advertiser;

import java.util.Optional;

@Repository
public interface AdvertiserRepository extends JpaRepository<Advertiser,Long> {
    public Optional<Advertiser> findByAccountEmail (String email);

}
