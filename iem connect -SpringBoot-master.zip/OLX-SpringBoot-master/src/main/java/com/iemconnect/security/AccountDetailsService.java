package com.iemconnect.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.iemconnect.model.Account;
import com.iemconnect.repository.AccountRepository;



public class AccountDetailsService implements UserDetailsService {
    @Autowired
    private AccountRepository accountRepository;
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
       Account account= accountRepository.findByEmail(email).orElseThrow(() -> new UsernameNotFoundException("No such User"));
       return new AccountDetails(account);

    }
}
