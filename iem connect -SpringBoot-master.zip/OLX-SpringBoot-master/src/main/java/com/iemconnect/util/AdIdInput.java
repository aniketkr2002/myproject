package com.iemconnect.util;

import lombok.Data;

@Data
public class AdIdInput {
    private Long adId;
}
