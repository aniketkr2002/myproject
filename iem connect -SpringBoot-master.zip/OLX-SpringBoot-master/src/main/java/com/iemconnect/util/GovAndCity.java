package com.iemconnect.util;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class GovAndCity {
    private String gov;
    private String city;

}
